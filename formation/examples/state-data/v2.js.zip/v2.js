exports.default = function () {
	return Promise.resolve('v2')
}

exports.default = function (e) {
	return {
		statusCode: 200,
		body: '<h1>SSR Lambda result...</h1>',
	}
}

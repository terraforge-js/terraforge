exports.default = function (e) {
	return Promise.resolve(true)
}
